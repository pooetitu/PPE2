package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ConnexionClient implements Runnable {

	private static Socket sock = null;
	private static BufferedReader br = null;
	private final int port = 5657;
	private final String host = "127.0.0.1";
	private static String send = "";

	private static PrintStream ps;

	public ConnexionClient() {
		try {
			sock = new Socket(host, port);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
			try {
				Thread envoie = new Thread() {
					public void run() {
						Scanner sc = new Scanner(System.in);
						while (!sock.isClosed()) {
							send = sc.nextLine();
							ps.println(send);
						}
						sc.close();
					}
				};
				envoie.start();
				while (!sock.isClosed()) {

					String reponse;
					reponse = br.readLine();
					System.out.println(reponse);
				}
				sock.close();
				ps.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			

		
	}

}
