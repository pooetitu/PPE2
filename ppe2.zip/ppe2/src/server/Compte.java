package server;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import server.commands.SQL;

public class Compte implements Serializable {
	private static final long serialVersionUID = 8395100702175098552L;
	private String nom, prenom, email, mdp, ddn;
	private int id, nbperso;
	private Personnage[] p = new Personnage[2];
	private transient final File file = new File(String.valueOf(id));

	public Compte(String nom, String prenom, String email, String mdp, String ddn) {
		this.ddn = ddn;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.mdp = mdp;

		SQL sql = new SQL();

		sql.userCreation(nom, prenom, email, mdp, ddn);

		this.id = sql.userConnection(email, mdp);
	}

	public File getFile() {
		return file;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Personnage getP(int x) {
		Personnage p1;
		if (x == 1) {
			p1 = this.p[1];
		} else {
			p1 = this.p[2];
		}
		return p1;
	}

	public void setP(Personnage[] p) {
		this.p = p;
	}

	public void modifier() {

	}

	public void creePerso() {
		if (nbperso < 2) {
			System.out.println("recup nom");
			System.out.println("choix nuker ou soigneur");
			String choixClasse = null;
			String nomPerso = null;
			switch (choixClasse) {
			case ("Nuker"): {
				p[nbperso] = new Nuker(nomPerso);
				nbperso++;
				break;
			}
			case ("Soigneur"): {
				p[nbperso] = new Soigneur(nomPerso);
				nbperso++;
				break;
			}
			}
		}
	}

	public void save() {
		ObjectOutputStream oos = null;
		try {

			final FileOutputStream fichier = new FileOutputStream(file);

			oos = new ObjectOutputStream(fichier);
			oos.writeObject(this);

		} catch (final IOException e) {

			e.printStackTrace();

		}
	}

	public void delPerso() {

	}

	public void delCompte() {

	}

}
