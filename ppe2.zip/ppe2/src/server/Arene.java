package server;

import java.io.Serializable;
import java.util.Random;

import server.items.Armure;
import server.items.Bouclier;
import server.items.Casque;
import server.items.Epee;

public class Arene implements Serializable,Runnable {
	private static final long serialVersionUID = -3737205430085844591L;
	private int tour;
	private int rndMap;
	private Group g1,g2;
	public Arene(Group g1,Group g2){
		this.g1=g1;
		this.g2=g2;
		Random rnd = new Random();
		this.rndMap = rnd.nextInt(4) + 0;
	}
	public int getTour() {
		return tour;
	}
	

	public void setTour(int tour) {
		this.tour = tour;
	}
	

	@Override
	public String toString() {
		return "Arene [rndMap=" + rndMap + ", g1=" + g1 + ", g2=" + g2 + "]";
	}
	public void startGame(Group g1, Group g2) {
		while ((!g1.getP(1).isDead() & !g1.getP(2).isDead()) || (!g2.getP(1).isDead() & !g2.getP(2).isDead())) {
			
			this.send();
			g1.getP(1).setEvite(1);
			if (g1.getP(1).getPv() + g1.getP(1).getA().getPv() <= 0) {
				g1.getP(1).setDead(true);
			}
			if (g1.getP(1).getTaunt() <= tour && !g1.getP(1).isDead()) {
				g1.getP(1).round(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2), this);
				this.updateData(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2));
			}
			
			this.send();
			g1.getP(2).setEvite(1);
			if (g1.getP(2).getPv() + g1.getP(2).getA().getPv() <= 0) {
				g1.getP(2).setDead(true);
			}
			if (g1.getP(2).getTaunt() <= tour && !g1.getP(2).isDead()) {
				g1.getP(2).round(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2), this);
				this.updateData(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2));
			}

			this.send();
			g2.getP(1).setEvite(1);
			if (g2.getP(1).getPv() + g2.getP(1).getA().getPv() <= 0) {
				g2.getP(1).setDead(true);
			}
			if (g2.getP(1).getTaunt() <= tour && !g2.getP(1).isDead()) {
				g2.getP(1).round(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2), this);
				this.updateData(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2));
			}

			this.send();
			g2.getP(2).setEvite(1);
			if (g2.getP(2).getPv() + g2.getP(2).getA().getPv() <= 0) {
				g2.getP(2).setDead(true);
			}
			if (g2.getP(2).getTaunt() <= tour && !g2.getP(2).isDead()) {
				g2.getP(2).round(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2), this);
				this.updateData(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2));
			}
			tour++;
		}
		if (g2.getP(1).isDead() && g2.getP(2).isDead()) {
			win(g1.getP(1), g1.getP(2));
			lose(g2.getP(1), g2.getP(2));
		} else if (g1.getP(1).isDead() && g1.getP(2).isDead()) {
			lose(g1.getP(1), g1.getP(2));
			win(g2.getP(1), g2.getP(2));
		}
		updateData(g1.getP(1), g1.getP(2), g2.getP(1), g2.getP(2));
	}

	private void lose(Personnage p1, Personnage p2) {
		dropItem(p1, "l");
		dropXp(p1, "l");
		dropItem(p2, "l");
		dropXp(p2, "l");
	}

	private void win(Personnage p1, Personnage p2) {
		dropItem(p1, "w");
		dropXp(p1, "w");
		dropItem(p2, "w");
		dropXp(p2, "w");
	}

	private void dropItem(Personnage p, String statut) {
		int rng1 = 100, rng2;
		Random rnd = new Random();
		switch (statut) {
		case ("w"): {
			rng1 = (rnd.nextInt(100) + 1);
		}
		case ("l"): {
			rng1 = (rnd.nextInt(100) + 16);
		}
		}
		rng2 = (rnd.nextInt(4) + 0);
		int rng3 = 0;
		if (rng1 <= 50 && rng1 >= 36) {
			rng3 = 0;
		} else if (rng1 <= 35 && rng1 >= 16) {
			rng3 = 1;
		} else if (rng1 <= 15 && rng1 >= 6) {
			rng3 = 2;
		} else if (rng1 <= 5 && rng1 >= 3) {
			rng3 = 3;
		} else if (rng1 <= 2 && rng1 >= 0) {
			rng3 = 4;
		}

		switch (rng2) {
		case (0): {
			if (p.getE().getForce() < ((Epee) Launcher.listItems[0][rng3]).getForce()) {
				p.setE((Epee) Launcher.listItems[0][rng3]);
			}
		}
		case (1): {
			if (p.getC().getBoostxp() < ((Casque) Launcher.listItems[1][rng3]).getBoostxp()) {
				p.setC((Casque) Launcher.listItems[1][rng3]);
			}
		}
		case (2): {
			if (p.getA().getPv() < ((Armure) Launcher.listItems[2][rng3]).getPv()) {
				p.setA((Armure) Launcher.listItems[2][rng3]);
			}

		}
		case (3): {
			if (p.getB().getEsquive() < ((Bouclier) Launcher.listItems[3][rng3]).getEsquive()) {
				p.setB((Bouclier) Launcher.listItems[3][rng3]);
			}
		}
		}
	}

	private void dropXp(Personnage p, String statut) {
		Random rnd = new Random();
		if (statut == "w") {
			int rng = (rnd.nextInt(80) + 50);
			rng += rng * p.getC().getBoostxp() / 100;
			p.setXp(p.getXp() + rng);
		} else if (statut == "l") {
			int rng = (rnd.nextInt(80) + 50);
			rng += rng * p.getC().getBoostxp() / 25;
			p.setXp(p.getXp() + rng);
		}
	}

	private void updateData(Personnage p1, Personnage p2, Personnage p3, Personnage p4) {
		p1.reset();
		p2.reset();
		p3.reset();
		p4.reset();
		
	}
	public void send() {
		g1.getC1().sendObject(this);
		g2.getC1().sendObject(this);
		g1.getC2().sendObject(this);
		g2.getC2().sendObject(this);
	}
	@Override
	public void run() {
		this.startGame(g1, g2);
	}


}
