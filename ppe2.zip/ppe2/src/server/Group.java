package server;

import java.io.Serializable;
import java.util.List;

import server.commands.ClientConnection;

public class Group implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8767605456114071945L;
	private transient ClientConnection c1, c2;
	private Personnage p[] = new Personnage[2];
	private boolean inSearch = false, inGame = false;

	public Group(Personnage p, Personnage p1, ClientConnection c1, ClientConnection c2) {
		this.p[0] = p;
		this.p[1] = p1;
		this.c1 = c1;
		this.c2 = c2;
	}

	@Override
	public String toString() {
		return "Group [p=" + p[0] + " p2 = " + p[1] + "]";
	}

	public Personnage getP(int x) {
		return p[x];
	}

	public void setP(Personnage[] g) {
		this.p = g;
	}

	public boolean isInSearch() {
		return inSearch;
	}

	public void setInSearch(boolean inSearch) {
		this.inSearch = inSearch;
	}

	public boolean isInGame() {
		return inGame;
	}

	public void setInGame(boolean inGame) {
		this.inGame = inGame;
	}

	public ClientConnection getC1() {
		return c1;
	}

	public void setC1(ClientConnection c1) {
		this.c1 = c1;
	}

	public ClientConnection getC2() {
		return c2;
	}

	public void setC2(ClientConnection c2) {
		this.c2 = c2;
	}

	public void startSearch(List<Group> g) {
		this.setInSearch(true);
		for (int i = 0; i < g.size() && this.isInSearch(); i++) {
			if (!g.get(i).isInGame() && g.get(i).isInSearch() && g.get(i) != this && !g.isEmpty()) {
				this.setInSearch(false);
				this.setInGame(true);
				g.get(i).setInSearch(false);
				g.get(i).setInGame(true);
				Arene a = new Arene(this, g.get(i));
				Thread t = new Thread(a);
				System.out.println("Game started");
				a.startGame(this, g.get(i));
				this.setInGame(false);
				g.get(i).setInGame(false);
			}
		}
	}

}
