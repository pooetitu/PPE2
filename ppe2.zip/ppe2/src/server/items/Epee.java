package server.items;

public class Epee extends Item {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4760528421816560395L;

	public Epee(String nom, int taux, int force) {
		super(nom, taux);
		// TODO Auto-generated constructor stub
	}

	private int force;

	public int getForce() {
		return force;
	}

	public void setForce(int force) {
		this.force = force;
	}

}
