package server.items;

import java.io.Serializable;

public abstract class Item  implements Serializable{
	private static final long serialVersionUID = -4562912974939608382L;
	private int taux;
	protected String nom;
	public Item(String nom,int taux) {
		
	}
	public int getTaux() {
		return taux;
	}

	public void setTaux(int taux) {
		this.taux = taux;
	}
}