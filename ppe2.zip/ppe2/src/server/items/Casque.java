package server.items;

public class Casque extends Item {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2469836760868874546L;

	public Casque(String nom, int taux, int boostxp) {
		super(nom, taux);
		// TODO Auto-generated constructor stub
	}

	private int boostxp;

	public int getBoostxp() {
		return boostxp;
	}

}
