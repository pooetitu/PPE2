package server.items;

public class Armure extends Item {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8330372865359318042L;

	public Armure(String nom, int taux, int pv) {
		super(nom, taux);
		// TODO Auto-generated constructor stub
		this.pv=pv;
	}

	private int pv;

	public int getPv() {
		return pv;
	}

}
