package server.items;

public class Bouclier extends Item {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3103384667382899607L;

	public Bouclier(String nom, int taux, int esquive) {
		super(nom, taux);
		// TODO Auto-generated constructor stub
	}

	public int getEsquive() {
		return esquive;
	}

	public void setEsquive(int esquive) {
		this.esquive = esquive;
	}

	private int esquive;
}
