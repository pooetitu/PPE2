package server.commands;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import server.Arene;
import server.Group;

public class GameServer {
	public static List<Group> listGroup=new ArrayList<Group>();
	public static List<ClientConnection> listClient= new ArrayList<ClientConnection>();
	public static List<Arene> listArene=new ArrayList<Arene>();
	private ServerSocket ss=null;
	private final static int port=5657;
	private final static String host="127.0.0.1";
	private boolean running=true;

	public GameServer() {
		
		try {
			ss=new ServerSocket(port,20,InetAddress.getByName(host));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void open(){
		Thread t = new Thread(new Runnable(){
			public void run(){
				while(running == true){
					try {
						Socket client = ss.accept();
						System.out.println("Connexion cliente re�ue.");  
						ClientConnection cl = new ClientConnection(client);
						listClient.add(cl);
						Thread t = new Thread(cl);
						t.start();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				try {
					ss.close();
				} catch (IOException e) {
					e.printStackTrace();
					ss = null;
				}
			}
		});
		t.start();
	}
}
