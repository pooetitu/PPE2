package server.commands;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import server.Compte;

public class SQL {

	private static Statement stmt = null;
	private static Connection dbcon = null;

	public static void startConnection() {
		try {
			Class.forName("org.postgresql.Driver");
			String dbUrl = "jdbc:postgresql://localhost:5432/postgres";
			String user = "postgres";
			String password = "pierre";
			dbcon = DriverManager.getConnection(dbUrl, user, password);
			System.out.println("connected");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean userExist(String email, String mdp) throws SQLException {
		int id = -1;
		try {
			stmt = dbcon.createStatement();
			ResultSet rs = stmt.executeQuery("select id from compte where email=" + email + "and mdp=" + mdp);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			stmt.close();
		} catch (SQLException e) {
			System.out.print("error");
		}
		if (id != -1) {
			return true;
		} else {
			return false;
		}

	}

	public int userConnection(String email, String mdp) {
		int id = 0;
		try {
			stmt = dbcon.createStatement();
			ResultSet rs = stmt
					.executeQuery("select nom,prenom,ddn from compte where email=" + email + "and mdp=" + mdp);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			stmt.close();
		} catch (SQLException e) {
			System.out.print("error");
		}
		return id;
	}

	public void userCreation(String nom, String prenom, String email, String mdp, String ddn) {
		try {
			Statement stmt = dbcon.createStatement();
			ResultSet r�sultats = stmt.executeQuery("insert into compte(nom,prenom,email,mdp,ddn)values(" + nom + ","
					+ prenom + "," + email + "," + mdp + "," + ddn + ")");
		} catch (SQLException e) {
			System.out.println("erreur");
		}

	}
}
