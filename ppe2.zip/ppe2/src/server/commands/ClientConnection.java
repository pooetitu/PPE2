package server.commands;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import server.Arene;
import server.Compte;
import server.Group;

public class ClientConnection implements Runnable {
	private Compte c = null;
	private Group g;
	private Arene a;
	private Socket sock;
	private PrintWriter writer = null;
	private BufferedInputStream reader = null;
	private ObjectOutputStream oos = null;
	private String toSend = "";

	public ClientConnection(Socket pSock) {
		sock = pSock;
	}

	public Arene getA() {
		return a;
	}

	public void setA(Arene a) {
		this.a = a;
	}

	public void connectionCompte(String email, String mdp) throws SQLException {
		SQL sql = new SQL();
		if (sql.userExist(email, mdp)) {
			int id = sql.userConnection(email, mdp);
			File file = new File(String.valueOf(id));

			ObjectInputStream ois = null;

			try {

				final FileInputStream fichier = new FileInputStream(file);

				ois = new ObjectInputStream(fichier);

				Compte c = (Compte) ois.readObject();
				System.out.println(c);

			} catch (final IOException e) {

				e.printStackTrace();

			} catch (final ClassNotFoundException e) {

				e.printStackTrace();

			}
		} else {
			toSend = "identifiant erron�";
		}
	}

	public void creationCompte(String nom, String prenom, String email, String mdp, String ddn) throws SQLException {
		SQL sql = new SQL();
		if (!sql.userExist(email, mdp)) {
			this.c = new Compte(nom, prenom, email, mdp, ddn);

			ObjectOutputStream oos = null;
			try {

				final FileOutputStream fichier = new FileOutputStream(c.getFile());

				oos = new ObjectOutputStream(fichier);
				oos.writeObject(c);
				oos = null;
			} catch (final IOException e) {

				e.printStackTrace();

			}

		} else {
			toSend = "email deja utilis�";
		}
	}

	public Group getG() {
		return g;
	}

	public void setG(Group g) {
		this.g = g;
	}

	public void run() {
		System.err.println("Lancement du traitement de la connexion cliente");

		boolean closeConnexion = false;
		while (!sock.isClosed()) {
			try {
				writer = new PrintWriter(sock.getOutputStream());
				reader = new BufferedInputStream(sock.getInputStream());
				oos = new ObjectOutputStream(sock.getOutputStream());
				String request = read();
				InetSocketAddress remote = (InetSocketAddress) sock.getRemoteSocketAddress();
				String servRequests = "";
				servRequests = "Demande de l'adresse : " + remote.getAddress().getHostAddress() + ".";
				servRequests += "\t -> Commande re�ue : " + request + "\n";
				System.err.println("\n" + servRequests);
				List<String> cmd = Arrays.asList(request.trim().split("\\s+"));
				toSend = "";
				switch (cmd.get(1).toUpperCase()) {
				case ("CONNECT"): {
					switch (cmd.get(2).toUpperCase()) {
					case ("SIGNIN"): {
						try {
							creationCompte(cmd.get(3), cmd.get(4), cmd.get(5), cmd.get(6), cmd.get(7));
						} catch (SQLException e) {
							System.err.println("erreur connection signup");
						}
						break;
					}
					case ("SIGNUP"): {
						try {
							connectionCompte(cmd.get(3), cmd.get(4));
						} catch (SQLException e) {
							System.err.println("erreur connection signup");
						}
						break;
					}
					}
					break;
				}
				case ("BATTLE"): {
					switch (cmd.get(2).toUpperCase()) {
					case ("START"): {
						switch (cmd.get(3)) {
						case ("SOLO"): {
							switch (cmd.get(3)) {
							case ("1"): {
								this.c.getP(1).startGame(GameServer.listClient, this);
								break;
							}
							case ("2"): {
								this.c.getP(2).startGame(GameServer.listClient, this);
								break;
							}
							}
							break;
						}
						case ("GROUP"): {
							this.g.startSearch(GameServer.listGroup);
							break;
						}
						}
						break;
					}
					case ("INGAME"): {

						break;
					}
					}
					break;
				}
				}

				cmd.clear();
				writer.write(toSend);
				writer.flush();
				if (closeConnexion) {
					System.err.println("connection closed ! ");
					writer = null;
					reader = null;
					oos = null;
					sock.close();
					GameServer.listClient.remove(this);
					break;
				}
			} catch (SocketException e) {
				System.err.println("Connection closed ! ");
				break;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Compte getC() {
		return c;
	}

	public void setC(Compte c) {
		this.c = c;
	}

	public void sendObject(Object o) {
		try {
			oos = new ObjectOutputStream(this.sock.getOutputStream());
			oos.writeObject(o);
			oos = null;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String read() throws IOException {
		String response = "";
		int stream;
		byte[] b = new byte[4096];
		stream = reader.read(b);
		response = new String(b, 0, stream);
		return response;
	}

}
