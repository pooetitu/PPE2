package server;

import java.util.Random;
import java.util.Scanner;

import server.items.Armure;
import server.items.Bouclier;
import server.items.Casque;
import server.items.Epee;

public class Nuker extends Personnage {
	private static final long serialVersionUID = 1651299842505324764L;
	private int cdUlti = 0;

	public void reset() {
		super.reset();
		cdUlti=0;
	}
	public Nuker(String nom) {
		super(nom);
		this.nuker = true;
		this.lvl = 0;
		this.pv = 250;
		this.pvmax = 250;
		this.force = 50;
		this.xp = 0;
		this.pc = 0;
		this.lvlComp1 = 0;
		this.lvlComp2 = 0;
		this.lvlComp3 = 0;
		this.a = new Armure("", 0, 0);
		this.b = new Bouclier("", 0, 0);
		this.c = new Casque("", 0, 0);
		this.e = new Epee("", 0, 0);
	}

	// bdd
	public Nuker(String nom, int xp, int pcUsed, int lvlComp1, int lvlComp2, int lvlComp3, String slot1Name,
			int slot1Taux, int slot1Boost, String slot2Name, int slot2Taux, int slot2Boost, String slot3Name,
			int slot3Taux, int slot3Boost, String slot4Name, int slot4Taux, int slot4Boost) {
		super(nom, xp, pcUsed, lvlComp1, lvlComp2, lvlComp3, slot1Name, slot1Taux, slot1Boost, slot2Name, slot2Taux,
				slot2Boost, slot3Name, slot3Taux, slot3Boost, slot4Name, slot4Taux, slot4Boost);
		this.nuker = true;
		this.force = 50;
		this.pvmax = 250;
		this.pv = 250;
	}

	public void attaque(Personnage p) {
		Random rnd = new Random();
		int atk = (rnd.nextInt(this.force + this.getE().getForce() - (this.force + this.getE().getForce() * 3 / 100))
				+ this.force + this.getE().getForce() + (this.force + this.getE().getForce() * 3 / 100));
		if (p.getLvlComp1() > this.getLvlComp3() + 3) {
			p.setPv(p.getPv());
		} else {
			p.setPv(p.getPv() - atk * p.getEvite());
		}
	}

	public void control(Personnage p,Arene a) {
		p.setTaunt(a.getTour()+5);
	}

	public void eviter() {
		this.evite = 0;
	}

	public void round(Personnage p1, Personnage p2, Personnage p3, Personnage p4,Arene a) {
		System.out.println("choix ATTAQUE CONTROL EVITE ATTAQUEULT");
		Scanner sc = new Scanner(System.in);
		String cmdsclients = sc.nextLine();
		this.coolDown();
		if(this.cdUlti>0) {
			this.cdUlti--;
		}
		switch (cmdsclients) {
		case ("ATTAQUE"): {
			if (this.cd1 <= 0) {
				if (this == p1 || this == p2) {
					switch (cmdclients) {
					case (1): {
						this.attaque(p3);
						break;
					}
					case (2): {
						this.attaque(p4);
						break;
					}
					}
				} else if (this == p3 || this == p4) {
					switch (cmdclients) {
					case (1): {
						this.attaque(p1);
						break;
					}
					case (2): {
						this.attaque(p2);
						break;
					}
					}
				}
				this.cd1 = 3 / this.lvlComp1;
			} else {
				System.out.println("wait for cooldown");
			}
			break;
		}
		case ("CONTROL"): {
			if (this.cd2 <= 0) {
				if (this == p1 || this == p2) {
					switch (cmdclients) {
					case (1): {
						this.control(p3,a);
						break;
					}
					case (2): {
						this.control(p4,a);
						break;
					}
					}
				} else if (this == p3 || this == p4) {
					switch (cmdclients) {
					case (1): {
						this.attaque(p1);
						break;
					}
					case (2): {
						this.attaque(p2);
						break;
					}
					}
				}
				this.cd2 = 4 / this.lvlComp2;
			} else {
				System.out.println("wait for cooldown");
			}
			break;
		}
		case ("EVITE"): {
			if (this.cd3 <= 0) {
				this.eviter();
				this.cd3 = 4 / this.lvlComp3;
			} else {
				System.out.println("wait for cooldown");
			}
			break;
		}
		case ("ATTAQUEULT"): {
			if (this.cdUlti <= 0) {
				if (this == p1 || this == p2) {
					switch (cmdclients) {
					case (1): {
						this.attaque(p3);
						break;
					}
					case (2): {
						this.attaque(p4);
						break;
					}
					}
				} else if (this == p3 || this == p4) {
					switch (cmdclients) {
					case (1): {
						this.attaque(p1);
						break;
					}
					case (2): {
						this.attaque(p2);
						break;
					}
					}
				}
				this.cdUlti = 6;
			} else {
				System.out.println("wait for cooldown");
			}
			break;
		}
		}
	}
}
