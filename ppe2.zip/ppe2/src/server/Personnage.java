package server;

import java.io.Serializable;
import java.util.List;

import server.commands.ClientConnection;
import server.commands.GameServer;
import server.items.Armure;
import server.items.Bouclier;
import server.items.Casque;
import server.items.Epee;

public abstract class Personnage implements Serializable{
	private static final long serialVersionUID = 6437815601023483295L;
	protected String cmdsclients;
	protected int cmdclients;
	protected boolean nuker, soigneur, dead = false, searching = false, playing = false;

	public boolean isSearching() {
		return searching;
	}

	public void setSearching(boolean searching) {
		this.searching = searching;
	}

	public boolean isPlaying() {
		return playing;
	}

	public void setPlaying(boolean playing) {
		this.playing = playing;
	}

	protected Armure a;
	protected Epee e;
	protected Bouclier b;
	protected Casque c;
	protected int xp, pv, pvmax, lvl, pc, pcUsed, lvlComp1, lvlComp2, lvlComp3, cd1 = 0, cd2 = 0, cd3 = 0, force,
			evite = 1, taunt;

	public int getTaunt() {
		return taunt;
	}

	@Override
	public String toString() {
		return "Personnage [nom=" + nom + "]";
	}

	public void setTaunt(int taunt) {
		this.taunt = taunt;
	}

	public boolean isNuker() {
		return nuker;
	}

	public boolean isSoigneur() {
		return soigneur;
	}

	public int getEvite() {
		return evite;
	}

	public void setEvite(int evite) {
		this.evite = evite;
	}

	public int getPvmax() {
		return pvmax;
	}

	public void setPvmax(int pvmax) {
		this.pvmax = pvmax;
	}

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public Armure getA() {
		return a;
	}

	public void setA(Armure a) {
		this.a = a;
	}

	public Epee getE() {
		return e;
	}

	public void setE(Epee e) {
		this.e = e;
	}

	public Bouclier getB() {
		return b;
	}

	public void setB(Bouclier b) {
		this.b = b;
	}

	public Casque getC() {
		return c;
	}

	public void setC(Casque c) {
		this.c = c;
	}

	public int getPv() {
		return pv;
	}

	public void setPv(int pv) {
		this.pv = pv;
	}

	public int getLvl() {
		return lvl;
	}

	public void setLvl(int lvl) {
		this.lvl = lvl;
	}

	public int getPc() {
		return pc;
	}

	public void setPc(int pc) {
		this.pc = pc;
	}

	public int getLvlComp1() {
		return lvlComp1;
	}

	public void setLvlComp1(int lvlComp1) {
		this.lvlComp1 = lvlComp1;
	}

	public int getLvlComp2() {
		return lvlComp2;
	}

	public void setLvlComp2(int lvlComp2) {
		this.lvlComp2 = lvlComp2;
	}

	public int getLvlComp3() {
		return lvlComp3;
	}

	public void setLvlComp3(int lvlComp3) {
		this.lvlComp3 = lvlComp3;
	}

	public int getforce() {
		return force;
	}

	public void setforce(int force) {
		this.force = force;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	private String nom;

	protected Personnage(String nom) {
		this.nom = nom;
	}

	protected Personnage(String nom, int xp, int pcUsed, int lvlComp1, int lvlComp2, int lvlComp3, String slot1Name,
			int slot1Taux, int slot1Boost, String slot2Name, int slot2Taux, int slot2Boost, String slot3Name,
			int slot3Taux, int slot3Boost, String slot4Name, int slot4Taux, int slot4Boost) {
		this.updateLvl();
		this.xp = xp;
		this.pcUsed = pcUsed;
		this.lvlComp1 = 0;
		this.lvlComp2 = 0;
		this.lvlComp3 = 0;
		this.a = new Armure(slot1Name, slot1Taux, slot1Boost);
		this.b = new Bouclier(slot2Name, slot2Taux, slot2Boost);
		this.c = new Casque(slot3Name, slot3Taux, slot3Boost);
		this.e = new Epee(slot4Name, slot4Taux, slot4Boost);
	}

	public void updateLvl() {
		this.setLvl(this.getXp() / 100);
		this.setPc(this.getXp() / 100 - pcUsed);
	}

	public void lvlupComp(int comp) {
		if (this.getPc() > 0 && comp == 1 && lvlComp1 < 5) {
			this.lvlComp1++;
			this.pcUsed++;
		} else if (this.getPc() > 0 && comp == 2 && lvlComp2 < 5) {
			this.lvlComp2++;
			this.pcUsed++;
		} else if (this.getPc() > 0 && comp == 3 && lvlComp3 < 5) {
			this.lvlComp3++;
			this.pcUsed++;
		}

	}

	public void sendData() {
		this.setDead(false);
		this.pv = this.pvmax;

	}

	public boolean isDead() {
		return dead;
	}

	public void setDead(boolean dead) {
		this.dead = dead;
	}

	public void coolDown() {
		if (this.cd1 > 1) {
			cd1--;
		}
		if (this.cd2 > 1) {
			cd2--;
		}
		if (this.cd3 > 1) {
			cd3--;
		}
	}

	public void startGame(List<ClientConnection> listClient,ClientConnection c) {
		boolean found;
		do {
			for (int i = 0; i < listClient.size(); i++) {
				for (int j = 0; i < 2; j++) {
					if (listClient.get(i).getC().getP(j).isSearching()) {
						found=true;
						this.setSearching(false);
						listClient.get(i).getC().getP(j).setSearching(false);
						Group g = new Group(this, listClient.get(i).getC().getP(j),c,listClient.get(1));
						GameServer.listGroup.add(g);
						c.setG(g);
						listClient.get(i).setG(g);
						g.startSearch(GameServer.listGroup);
						GameServer.listGroup.remove(g);
						g = null;
						c.setG(null);
						listClient.get(i).setG(null);
					}
					else {
						found=false;
					}
				}
			}
		}while(found=false);
	}
	public void reset() {
		cd1=0;
		cd2=0;
		cd3=0;
		pv=pvmax;
	}
	public abstract void round(Personnage p1, Personnage p2, Personnage p3, Personnage p4, Arene a);
}
