package server;

import server.commands.GameServer;
import server.commands.SQL;
import server.items.Armure;
import server.items.Bouclier;
import server.items.Casque;
import server.items.Epee;
import server.items.Item;

public class Launcher {
	public Launcher() {
		SQL.startConnection();
		// creation des epees
		listItems[0][0] = new Epee("epee1", 50, 5);
		listItems[0][1] = new Epee("epee2", 35, 10);
		listItems[0][2] = new Epee("epee3", 15, 15);
		listItems[0][3] = new Epee("epee4", 5, 20);
		listItems[0][4] = new Epee("epee5", 2, 30);

		// creation des casques
		listItems[1][0] = new Casque("casque1", 50, 2);
		listItems[1][1] = new Casque("casque2", 35, 5);
		listItems[1][2] = new Casque("casque3", 15, 10);
		listItems[1][3] = new Casque("casque4", 5, 15);
		listItems[1][4] = new Casque("casque5", 2, 20);

		// creation des armures
		listItems[2][0] = new Armure("armure1", 50, 20);
		listItems[2][1] = new Armure("armure2", 35, 30);
		listItems[2][2] = new Armure("armure3", 15, 45);
		listItems[2][3] = new Armure("armure4", 5, 60);
		listItems[2][4] = new Armure("armure5", 2, 85);

		// creation des boucliers
		listItems[3][0] = new Bouclier("bouclier1", 50, 5);
		listItems[3][1] = new Bouclier("bouclier2", 35, 10);
		listItems[3][2] = new Bouclier("bouclier3", 15, 15);
		listItems[3][3] = new Bouclier("bouclier4", 5, 20);
		listItems[3][4] = new Bouclier("bouclier5", 2, 25);

	}

	public final static Item[][] listItems = new Item[4][5];

	public static void main(String[] args) {
		Launcher l = new Launcher();

		GameServer gs = new GameServer();
		gs.open();
		System.out.println("Serveur lanc�.");

		// ecriture object

//		Personnage p1 = new Soigneur("pooetitu");
//		Personnage p2 = new Nuker("pooet");
//		Personnage p3 = new Soigneur("poooooet");
//		Personnage p4 = new Nuker("poetituuuuuu");
//		
//		Group g1= new Group(p1,p2,null,null);
//		Group g2=new Group(p3,p4,null,null);
//		File file = new File("0");
//		Arene a=new Arene(g1,g2);
//		System.out.println(a);
//		ObjectOutputStream oos = null;
//		try {
//
//			final FileOutputStream fichier = new FileOutputStream(file);
//
//			oos = new ObjectOutputStream(fichier);
//			oos.writeObject(a);
//
//		} catch (final IOException e) {
//
//			e.printStackTrace();
//
//		}
//		
//		
//		
//		ObjectInputStream ois = null;
//		
//		 
//		
//		try {
//		
//		final FileInputStream fichier = new FileInputStream(file);
//		
//		ois = new ObjectInputStream(fichier);
//
//
//		Arene a1 = (Arene) ois.readObject();
//		System.out.println(a1);
//		
//		} catch (final IOException e) {
//		
//		e.printStackTrace();
//		
//		} catch (final ClassNotFoundException e) {
//		
//		e.printStackTrace();
//		
//		}

	}

}
